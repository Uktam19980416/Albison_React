import Ads from '../../../helpers/Ads'
function ProductsSale() {
  return (
    <>
      <Ads stat="xit" />
      {/* <Outlet /> */}
    </>
  )
}

export default ProductsSale

import Ads from '../../../helpers/Ads'

function ProductsSale2() {
  return (
    <>
      <Ads stat="onSale" />
    </>
  )
}

export default ProductsSale2

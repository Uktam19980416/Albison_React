// import Ads from '../../../helpers/Ads'
import Filter from './Filter2'
import ProductsSale2 from './ProductsSale2'
// import ProductsSale2 from './ProductsSale2'

function Sales() {
  return (
    <>
      <Filter />
      {/* <Ads stat="onSale" /> */}
      <ProductsSale2 />
    </>
  )
}

export default Sales
